<?php

include('helper.php');
//Param eg
$id = $params->get('id');


//Layout eg
require JModuleHelper::getLayoutPath('mod_empty_mod', $params->get('layout', 'default'));

