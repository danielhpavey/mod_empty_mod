# Very basic empty Joomla! Module

Just a *blank* module for installation in Joomla for module development


